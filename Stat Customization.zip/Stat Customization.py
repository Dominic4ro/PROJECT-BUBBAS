# health, strength, speed, magic, xp, action points
playerStats = [0, 0, 0, 0, 0, 0]
companionStats = [0, 0, 0, 0, 0, 0]
#enemyStats = [0, 0, 0, 0, 0, 0]



maxHealth = 100
maxStrength = 100
maxSpeed = 100
maxMagic = 100
maxXp = 100
xpIncrease = 10
statIncrease = 5
actionPointIncrease = 1

victory = True

def readFile():
    saveFile = open("saveFile.txt", "r")
    saveFile.readline()
    for x in range(len(playerStats)):
        playerStats[x] = int(saveFile.readline())
    for x in range(len(companionStats)):
        companionStats[x] = int(saveFile.readline())
    saveFile.close()


readFile()
#function for saving to the file
def n_game():
    saveFile = open("saveFile.txt", "w+")
    saveFile.write("Save 1")
    saveFile.write("\n")
    for x in range(len(playerStats)):
        saveFile.write(str(playerStats[x]))
        saveFile.write("\n")
    for x in range(len(companionStats)):
        saveFile.write(str(companionStats[x]))
        saveFile.write("\n")
    saveFile.close()



#if they win the battle, they gain xp and health reset to max
if (victory == True):
    playerStats[0] = maxHealth
    playerStats[4] += xpIncrease
    companionStats[0] = maxHealth
    companionStats[4] += xpIncrease
else:
    playerStats[0] += 0
    companionStats[0] += 0

#if the player meets/exceeds the max xp, the will gain an action point in which they choose what to do with
if (playerStats[4] >= maxXp):

    #calculates the player's xp after leveling up
    newXp = (playerStats[4]) - (maxXp)
    if (newXp >= 0):
        playerStats[4] = newXp
        companionStats[4] = newXp
    else:
        playerStats[4] = 0
        companionStats[4] = 0

        #gives the player one action point for leveling up
    playerStats[5] += actionPointIncrease
    companionStats[5] += actionPointIncrease

    print("You leveled up and gained one action point.\nWith that, you can upgrade one of your stats.\n")
    print("XP: " + str(playerStats[4]))
    print("Your Stats:\n1) Strength: " + str(playerStats[1]) + "\n2) Speed: " + str(playerStats[2]) + "\n3) Magic: " + str(playerStats[3]))
    # valid input checker
    while True:
        choice = input("Which will you upgarde: ")
        if not (choice == "1" or choice == "2" or choice == "3"):
            print("INVALID OPTION")
            continue
        else:
            break

    #if they choose to upgrade strength
    if (choice == "1"):
        playerStats[1] += statIncrease
        companionStats[1] += statIncrease
        playerStats[5] -= actionPointIncrease
        companionStats[5] -= actionPointIncrease
        print("\nYou upgraded your strength.")
        print("Your New Stats:\n1) Strength: " + str(playerStats[1]) + "\n2) Speed: " + str(playerStats[2]) + "\n3) Magic: " + str(playerStats[3]) + "\n")
    #if they choose to upgrade speed
    elif (choice == "2"):
        playerStats[2] += statIncrease
        companionStats[2] += statIncrease
        playerStats[5] -= actionPointIncrease
        companionStats[5] -= actionPointIncrease
        print("\nYou upgraded your speed.")
        print("Your New Stats:\n1) Strength: " + str(playerStats[1]) + "\n2) Speed: " + str(playerStats[2]) + "\n3) Magic: " + str(playerStats[3]) + "\n")
    #if they choose to upgrade magic
    elif (choice == "3"):
        playerStats[3] += statIncrease
        companionStats[3] += statIncrease
        playerStats[5] -= actionPointIncreas
        companionStats[5] -= actionPointIncrease
        print("\nYou upgraded your magic.")
        print("Your New Stats:\n1) Strength: " + str(playerStats[1]) + "\n2) Speed: " + str(playerStats[2]) + "\n3) Magic: " + str(playerStats[3]) + "\n")
n_game() #saves to file