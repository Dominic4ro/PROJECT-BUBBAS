import tkinter as tk
import pygame as pg
pg.init()



win = pg.display.set_mode((1280, 720))

pg.display.set_caption("Project Bubbas")

x = 64
y = 64
x2 = x - 64
y2 = y
width = 64
height = 64
vel = 5
char1 = pg.image.load('red mage down.png')
char2 = pg.image.load('warrior.png')

# text to screen
font = pg.font.SysFont(None, 25)

def drawPlayArea():
    # draw area
    pg.draw.rect(win, (150, 160, 170), (0, 0, 1280, 512))
    # draw characters
    win.blit(char2, (x2, y2))
    win.blit(char1, (x, y))
    # update display
    pg.display.update()

run = True
while run:
    #the press variable determines if a key has been pressed in this iteration of the loop
    press = False

    #time is delayed by 10 milliseconds each iteration of the loop regardless of which action is performed
    pg.time.delay(10)

    for event in pg.event.get():
        if event.type == pg.QUIT:
            run = False

    keys = pg.key.get_pressed()

    if keys[pg.K_w]:
        #keeps player in bounds
        if y > 0:
            #xt and yt are temporary variables to control companion's movement
            xt = x
            yt = y
            #for loop animates movement across one tile
            for count in range(0, 64):
                #if statement checks to see if player and companion are at same Y coordinate
                if y2 == yt:
                    #if the player and companion are at same Y coordinate, this if statement checks if companion is
                    #to the left or right of the player
                    if x2 < xt:
                        x2 += 1
                    else:
                        x2 -= 1
                #if player and companion are at two different y coordinates, test for above or below
                elif y2 > yt:
                    y2 -= 1
                else:
                    y2 += 1
                #player's vertical position goes 8 up, 8 times to reach one 64 pixel block
                y -= 1
                #drawPlayArea is called each loop in order to do the animation
                drawPlayArea()
                pg.time.delay(10)
            pg.time.delay(50)
            press = True

    if keys[pg.K_a]:
        if not press:
            if x > 0:
                yt = y
                xt = x
                for count in range(0, 64):
                    # if statement checks to see if player and companion are at same X coordinate
                    if x2 == xt:
                        # if the player and companion are at same Y coordinate, this if statement checks if companion is
                        # above or below the player
                        if y2 < yt:
                            y2 += 1
                        else:
                            y2 -= 1
                    # if player and companion are at two different x coordinates, test for left or right
                    elif x2 > xt:
                        x2 -= 1
                    else:
                        x2 += 1
                    # player's vertical position goes 8 up, 8 times to reach one 64 pixel block
                    x -= 1
                    drawPlayArea()
                    pg.time.delay(10)
                pg.time.delay(50)
                press = True

    if keys[pg.K_s]:
        if not press:
            if y < 448:
                xt = x
                yt = y
                for count in range(0, 64):
                    # if statement checks to see if player and companion are at same Y coordinate
                    if y2 == yt:
                        # if the player and companion are at same Y coordinate, this if statement checks if companion is
                        # to the left or right of the player
                        if x2 < xt:
                            x2 += 1
                        else:
                            x2 -= 1
                    # if player and companion are at two different y coordinates, test for above or below
                    elif y2 > yt:
                        y2 -= 1
                    else:
                        y2 += 1
                    # player's vertical position goes 8 up, 8 times to reach one 64 pixel block
                    y += 1
                    drawPlayArea()
                    pg.time.delay(10)
                pg.time.delay(50)
                press = True

    if keys[pg.K_d]:
        if not press:
            if x < 1216:
                yt = y
                xt = x
                for count in range(0, 64):
                    # if statement checks to see if player and companion are at same X coordinate
                    if x2 == xt:
                        # if the player and companion are at same Y coordinate, this if statement checks if companion is
                        # above or below the player
                        if y2 < yt:
                            y2 += 1
                        else:
                            y2 -= 1
                    # if player and companion are at two different x coordinates, test for left or right
                    elif x2 > xt:
                        x2 -= 1
                    else:
                        x2 += 1
                    # player's vertical position goes 8 up, 8 times to reach one 64 pixel block
                    x += 1
                    drawPlayArea()
                    pg.time.delay(10)
                pg.time.delay(50)
                press = True

    drawPlayArea()

    #draw bar
    win.blit(char1, (20, 530))
    win.blit(char2, (350, 530))

    pg.display.update()

pg.quit()


